package sample.project.feature1;

import dev.galasa.Test;
import dev.galasa.zos3270.ITerminal;
import dev.galasa.zos3270.Zos3270Terminal;

/**
 * A sample galasa test class 
 */
@Test
public class TestFeature1 {

	@Zos3270Terminal
	public ITerminal terminal;

	@Test
	public void mainframeTest() throws Exception{
		terminal.waitForTextInField("WELCOME TO USBANK");
		terminal.reportScreen();
	}
}
